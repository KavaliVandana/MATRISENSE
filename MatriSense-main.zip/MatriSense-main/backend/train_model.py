import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib  # Use joblib for saving the model

# Load the dataset
url = "https://raw.githubusercontent.com/akashjborah97/Maternal-Health-Risk-Predictor/refs/heads/main/Maternal%20Health%20Risk%20Data%20Set.csv"
df = pd.read_csv(url)

# Display dataset preview
print("Dataset preview:\n", df.head())

# Check for missing values
print("Missing values in dataset:\n", df.isnull().sum())

# 🚀 Fix Missing Values: Drop rows with NaN values
df = df.dropna().reset_index(drop=True)  # Reset index after dropping NaN

# Define input (X) and target (y) variables
X = df.drop(columns=['RiskLevel'])  # Features
y = df['RiskLevel']  # Target variable

# Convert categorical target variable into numerical labels
risk_mapping = {'low risk': 0, 'mid risk': 1, 'high risk': 2}
y = y.map(risk_mapping)

# 🚀 Final check: Ensure no missing or unknown values in y
if y.isnull().sum() > 0 or y.isna().sum() > 0:
    print("Error: NaN values still exist in y. Investigate the dataset.")
    exit()
print("Final y values:", y.unique())  # Should print [0 1 2]

# Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Train the Random Forest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate the model
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"✅ Model Accuracy: {accuracy:.2f}")

# Print classification report for better evaluation
print("\n🔹 Classification Report:")
print(classification_report(y_test, y_pred, target_names=risk_mapping.keys()))

# Save the trained model
joblib.dump(model, "risk_prediction_model.pkl")
print("✅ Model saved successfully as risk_prediction_model.pkl")

# Save feature importance for explainability
feature_importance = pd.DataFrame({'Feature': X.columns, 'Importance': model.feature_importances_})
feature_importance = feature_importance.sort_values(by='Importance', ascending=False)
feature_importance.to_csv("feature_importance.csv", index=False)
print("📊 Feature importance saved as feature_importance.csv")