from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import numpy as np

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Load the trained model
try:
    model = joblib.load("risk_prediction_model.pkl")  # Ensure this file exists
    print("✅ Model loaded successfully.")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    model = None  # Prevent crashing if model not found

# Mapping for prediction output
risk_levels = {0: "Low", 1: "Medium", 2: "High"}
suggestions = {
    "Low": "Maintain a healthy lifestyle and regular checkups.",
    "Medium": "Monitor your health and consult a doctor for precautionary measures.",
    "High": "Immediate medical attention is recommended.",
}

@app.route("/")
def home():
    return jsonify({"message": "Flask API is running!"})

@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Ensure request has JSON data
        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400

        data = request.get_json()
        print("📥 Received Data:", data)  # Debugging log

        if not model:
            return jsonify({"error": "Model not loaded. Check the server logs."}), 500

        # Extract individual features
        try:
            age = float(data.get("Age", -1))  # Provide default invalid value
            systolic_bp = float(data.get("SystolicBP", -1))
            diastolic_bp = float(data.get("DiastolicBP", -1))
            bs = float(data.get("BS", -1))
            body_temp = float(data.get("BodyTemp", -1))
            heart_rate = float(data.get("HeartRate", -1))

            # Check if any value is missing or invalid
            if min(age, systolic_bp, diastolic_bp, bs, body_temp, heart_rate) < 0:
                return jsonify({"error": "Invalid input values. Ensure all fields are filled correctly."}), 400

            # Combine features into an array
            features = np.array([[age, systolic_bp, diastolic_bp, bs, body_temp, heart_rate]])
        except ValueError:
            return jsonify({"error": "Invalid input. Ensure numerical values are provided."}), 400

        # Make prediction
        prediction = model.predict(features)[0]
        risk = risk_levels.get(prediction, "Unknown")

        print(f"📊 Prediction Result: {risk}")  # Debugging log

        return jsonify({
            "risk": risk,
            "suggestion": suggestions.get(risk, "No suggestion available")
        })

    except Exception as e:
        print(f"❌ Server error: {str(e)}")  # Log error on the backend
        return jsonify({"error": f"Server error: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5000)
