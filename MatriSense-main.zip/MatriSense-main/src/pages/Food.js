import React from "react";

const Food = () => {
  return (
    <div style={styles.container}>
      {/* Top Section with Two Images and Text in the Middle */}
      <div style={styles.topSection}>
        <img src="/images/food1.jpg" alt="Healthy Food 1" style={styles.image} />

        <div style={styles.textBox}>
          <h1 style={styles.heading}>Healthy Food for Pregnancy</h1>
          <p style={styles.text}>Discover essential nutrients and healthy meal ideas for a balanced pregnancy diet.</p>
        </div>

        <img src="/images/food3.jpg" alt="Healthy Food 3" style={styles.image} />
      </div>

      {/* Essential Nutrients Section */}
      <section style={styles.section}>
        <h2 style={styles.subHeading}>Essential Nutrients & Sources</h2>
        <div style={styles.grid}>
          <div style={styles.card}>
            <h3>Folic Acid</h3>
            <p>Spinach, lentils, oranges</p>
          </div>
          <div style={styles.card}>
            <h3>Iron</h3>
            <p>Red meat, beans, leafy greens</p>
          </div>
          <div style={styles.card}>
            <h3>Calcium</h3>
            <p>Milk, yogurt, almonds</p>
          </div>
          <div style={styles.card}>
            <h3>Protein</h3>
            <p>Eggs, chicken, tofu, beans</p>
          </div>
          <div style={styles.card}>
            <h3>Omega-3</h3>
            <p>Salmon, walnuts, flaxseeds</p>
          </div>
        </div>
      </section>

      {/* Foods to Avoid */}
      <section style={styles.section}>
        <h2 style={styles.subHeading}>Foods to Avoid During Pregnancy</h2>
        <div style={styles.avoidList}>
          <div style={styles.avoidItem}>🚫 Unpasteurized dairy & raw meats</div>
          <div style={styles.avoidItem}>🚫 Excessive caffeine & processed foods</div>
          <div style={styles.avoidItem}>🚫 Too much salt & sugar</div>
        </div>
      </section>

      {/* Meal Recommendations */}
      <section style={styles.section}>
        <h2 style={styles.subHeading}>Healthy Meal Ideas</h2>
        <div style={styles.mealBox}>
          <p><strong>🥣 Breakfast:</strong> Scrambled eggs with spinach & whole-grain toast</p>
          <p><strong>🥗 Lunch:</strong> Grilled chicken with quinoa & steamed vegetables</p>
          <p><strong>🍽️ Dinner:</strong> Salmon with roasted sweet potatoes & avocado</p>
        </div>
      </section>
    </div>
  );
};

// Styling for improved structure and readability
const styles = {
  container: {
    textAlign: "center",
    padding: "20px",
    fontFamily: "'Arial', sans-serif",
    backgroundColor: "#fffaf5",
  },
  topSection: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "20px",
    marginBottom: "30px",
  },
  image: {
    width: "28%",
    maxWidth: "280px",
    borderRadius: "10px",
  },
  textBox: {
    width: "40%",
    textAlign: "center",
  },
  heading: {
    fontSize: "28px",
    fontWeight: "bold",
    color: "#d63384",
    marginBottom: "10px",
  },
  text: {
    fontSize: "18px",
    color: "#444",
  },
  section: {
    padding: "20px",
    margin: "20px auto",
    maxWidth: "800px",
    backgroundColor: "white",
    borderRadius: "10px",
    boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
  },
  subHeading: {
    fontSize: "22px",
    fontWeight: "bold",
    color: "#d63384",
    marginBottom: "10px",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
    gap: "15px",
  },
  card: {
    padding: "15px",
    backgroundColor: "#ffeff7",
    borderRadius: "8px",
    textAlign: "center",
    fontSize: "16px",
    fontWeight: "bold",
  },
  avoidList: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "10px",
  },
  avoidItem: {
    padding: "10px",
    backgroundColor: "#ffe6e6",
    borderRadius: "8px",
    fontSize: "18px",
    fontWeight: "bold",
    width: "80%",
    textAlign: "center",
  },
  mealBox: {
    padding: "15px",
    backgroundColor: "#fff2e6",
    borderRadius: "8px",
    fontSize: "18px",
    fontWeight: "bold",
  },
};

export default Food;
