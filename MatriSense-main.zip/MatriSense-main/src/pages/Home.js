import React, { useState } from "react";

const Home = () => {
  const [formData, setFormData] = useState({
    Age: "",
    SystolicBP: "",
    DiastolicBP: "",
    BS: "",
    BodyTemp: "",
    HeartRate: "",
  });

  const [riskLevel, setRiskLevel] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const checkRisk = async () => {
    setLoading(true);
    setShowDetails(false);
  
    try {
      const inputData = {
        Age: parseFloat(formData.Age),
        SystolicBP: parseFloat(formData.SystolicBP),
        DiastolicBP: parseFloat(formData.DiastolicBP),
        BS: parseFloat(formData.BS),
        BodyTemp: parseFloat(formData.BodyTemp),
        HeartRate: parseFloat(formData.HeartRate),
      };
      console.log("1");
      console.log("Sending data:", inputData); // Debugging Line
  
      const response = await fetch("http://localhost:5000/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(inputData),
      });
      console.log("2");
      if (!response.ok) {
        throw new Error(`Failed to fetch: ${response.status}`);
      }
  
      const data = await response.json();
      console.log("Response received:", data); // Debugging Line
  
      if (data.risk) {
        setRiskLevel(data.risk);
      } else {
        throw new Error("Invalid response format");
      }
    } catch (error) {
      console.error("Error fetching risk level:", error);
      setRiskLevel("Error");
    }
  
    setLoading(false);
  };
  console.log("3");
  

  const riskDetails = {
    High: {
      color: "red",
      message: "Immediate medical attention is recommended.",
      steps: [
        "Consult a doctor immediately.",
        "Monitor your blood pressure and heart rate daily.",
        "Reduce salt and sugar intake in your diet.",
        "Stay hydrated and avoid stress.",
      ],
    },
    Medium: {
      color: "orange",
      message: "Monitor your health and take precautionary steps.",
      steps: [
        "Schedule regular health check-ups.",
        "Follow a balanced diet and exercise routine.",
        "Avoid excessive stress and caffeine intake.",
        "Track your vitals weekly.",
      ],
    },
    Low: {
      color: "green",
      message: "Maintain a healthy lifestyle for continued well-being.",
      steps: [
        "Continue following a healthy diet and routine.",
        "Stay active and get adequate sleep.",
        "Avoid smoking and alcohol consumption.",
        "Schedule a yearly health check-up.",
      ],
    },
  };

  return (
    <div style={styles.pageContainer}>
      <h1 style={styles.heading}>Maternal Health Risk Prediction</h1>

      <div style={styles.formContainer}>
        {[
          { label: "Age", key: "Age" },
          { label: "Systolic Blood Pressure", key: "SystolicBP" },
          { label: "Diastolic Blood Pressure", key: "DiastolicBP" },
          { label: "Blood Sugar", key: "BS" },
          { label: "Body Temperature", key: "BodyTemp" },
          { label: "Heart Rate", key: "HeartRate" },
        ].map(({ label, key }) => (
          <div key={key} style={styles.inputGroup}>
            <label>{label}:</label>
            <input
              type="number"
              name={key}
              value={formData[key]}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>
        ))}

        <button onClick={checkRisk} style={styles.button} disabled={loading}>
          {loading ? "Checking..." : "Check Your Risk Level"}
        </button>
      </div>

      {riskLevel && (
        <div style={styles.resultContainer}>
          <h2>
            Risk Level:{" "}
            <span
              style={{ ...styles.riskText, color: riskDetails[riskLevel]?.color }}
              onClick={() => setShowDetails(!showDetails)}
            >
              {riskLevel}
            </span>
          </h2>

          {showDetails && (
            <div>
              <p>{riskDetails[riskLevel]?.message}</p>
              <ul style={styles.suggestionsList}>
                {riskDetails[riskLevel]?.steps.map((step, index) => (
                  <li key={index}>{step}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Styles
const styles = {
  pageContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    minHeight: "100vh",
    paddingBottom: "60px", // Prevents overlap with footer
    backgroundImage: "url('/images/background.jpg')",
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
  heading: {
    fontSize: "30px",
    fontWeight: "bold",
    color: "black",
    marginTop: "20px",
  },
  formContainer: {
    background: "rgba(255, 255, 255, 0.8)",
    padding: "20px",
    borderRadius: "10px",
    width: "350px",
    boxShadow: "2px 2px 10px rgba(0,0,0,0.3)",
    textAlign: "center",
  },
  inputGroup: {
    marginBottom: "10px",
    textAlign: "left",
  },
  input: {
    width: "100%",
    padding: "8px",
    borderRadius: "5px",
    border: "1px solid black",
    marginTop: "5px",
  },
  button: {
    marginTop: "10px",
    padding: "10px 15px",
    backgroundColor: "black",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontWeight: "bold",
  },
  resultContainer: {
    marginTop: "20px",
    background: "rgba(255, 255, 255, 0.9)",
    padding: "10px",
    borderRadius: "10px",
    textAlign: "center",
    boxShadow: "2px 2px 10px rgba(0,0,0,0.3)",
  },
  riskText: {
    fontSize: "18px",
    fontWeight: "bold",
    cursor: "pointer",
    textDecoration: "underline",
  },
  suggestionsList: {
    textAlign: "left",
    paddingLeft: "20px",
  },
};

export default Home;
