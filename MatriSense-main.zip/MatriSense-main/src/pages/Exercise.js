import React from "react";

const Exercise = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Safe Exercises for Pregnancy</h1>
      <p style={styles.text}>
        Stay active during pregnancy with these safe and effective exercises. 
        These workouts help relieve pain, improve flexibility, and enhance overall well-being.
      </p>

      {/* General Safe Exercises */}
      <section style={styles.section}>
        <h2 style={styles.subHeading}>Recommended Exercises</h2>
        <div style={styles.grid}>
          <div style={styles.card}>
            <h3>🚶 Walking</h3>
            <p>Improves circulation, reduces swelling, and keeps you active.</p>
          </div>
          <div style={styles.card}>
            <h3>🧘 Prenatal Yoga</h3>
            <p>Reduces stress, improves flexibility, and strengthens muscles.</p>
          </div>
          <div style={styles.card}>
            <h3>🏊 Swimming</h3>
            <p>Relieves joint pain and strengthens muscles with low impact.</p>
          </div>
          <div style={styles.card}>
            <h3>🪑 Pelvic Tilts</h3>
            <p>Strengthens core muscles and reduces lower back pain.</p>
          </div>
        </div>
      </section>

      {/* Exercise Recommendations for Pain Relief */}
      <section style={styles.section}>
        <h2 style={styles.subHeading}>Exercises for Specific Pains</h2>

        <div style={styles.grid}>
          <div style={styles.card}>
            <h3>🔥 Lower Back Pain</h3>
            <p><strong>Cat-Cow Stretch:</strong> Increases spinal flexibility and reduces tension.</p>
            <p><strong>Pelvic Tilts:</strong> Strengthens lower back and relieves pain.</p>
          </div>

          <div style={styles.card}>
            <h3>🦵 Leg Cramps</h3>
            <p><strong>Calf Stretches:</strong> Improves blood circulation in legs.</p>
            <p><strong>Toe Flexes:</strong> Reduces muscle tension and prevents cramps.</p>
          </div>

          <div style={styles.card}>
            <h3>🦴 Pelvic Pain</h3>
            <p><strong>Butterfly Stretch:</strong> Increases hip flexibility and reduces pelvic discomfort.</p>
            <p><strong>Kegel Exercises:</strong> Strengthens pelvic floor muscles.</p>
          </div>

          <div style={styles.card}>
            <h3>👐 Wrist & Hand Pain</h3>
            <p><strong>Wrist Rotations:</strong> Reduces stiffness and improves flexibility.</p>
            <p><strong>Fist Clenches:</strong> Helps reduce swelling in hands.</p>
          </div>
        </div>
      </section>

      {/* Image Moved to Bottom */}
      <img 
        src="/images/exercise3.jpg" 
        alt="Pregnancy Exercise" 
        style={styles.image} 
      />
    </div>
  );
};

// Styling for a clean and modern layout
const styles = {
  container: {
    textAlign: "center",
    padding: "20px",
    fontFamily: "'Arial', sans-serif",
    backgroundColor: "#f9f9f9",
  },
  heading: {
    fontSize: "28px",
    fontWeight: "bold",
    color: "#d63384",
    marginBottom: "10px",
  },
  text: {
    fontSize: "18px",
    color: "#444",
    maxWidth: "700px",
    margin: "auto",
  },
  section: {
    padding: "20px",
    margin: "20px auto",
    maxWidth: "900px",
    backgroundColor: "white",
    borderRadius: "10px",
    boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
  },
  subHeading: {
    fontSize: "22px",
    fontWeight: "bold",
    color: "#d63384",
    marginBottom: "10px",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: "15px",
  },
  card: {
    padding: "15px",
    backgroundColor: "#ffeff7",
    borderRadius: "8px",
    textAlign: "center",
    fontSize: "16px",
    fontWeight: "bold",
  },
  image: {
    width: "80%",
    maxWidth: "500px",
    borderRadius: "10px",
    margin: "30px 0 10px 0", // Adjusted margin to position at the bottom
  },
};

export default Exercise;
