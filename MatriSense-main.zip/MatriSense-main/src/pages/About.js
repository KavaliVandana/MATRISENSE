import React from "react";

function About() {
  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>About Maternal Health Monitor</h1>
      <p style={styles.description}>
        <strong>Maternal Health Monitor</strong> is an AI-powered system designed to support pregnant women 
        by tracking their symptoms, monitoring vital health parameters, and providing real-time emergency alerts. 
        Our goal is to ensure early risk detection and improve maternal health outcomes using advanced 
        machine learning models and real-time monitoring.
      </p>

      <div style={styles.featuresContainer}>
        <h2 style={styles.subheading}>Key Features</h2>
        <ul style={styles.featureList}>
          <li>✔ Symptom tracking and analysis</li>
          <li>✔ Real-time emergency alerts</li>
          <li>✔ Personalized health recommendations</li>
          <li>✔ AI-powered predictive risk assessment</li>
        </ul>
      </div>
    </div>
  );
}

// Styling for better structure and readability
const styles = {
  container: {
    textAlign: "center",
    padding: "40px 20px",
    maxWidth: "800px",
    margin: "auto",
    fontFamily: "'Arial', sans-serif",
    lineHeight: "1.6",
    backgroundColor: "#fef4f8",
    borderRadius: "10px",
    boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
  },
  heading: {
    fontSize: "28px",
    fontWeight: "bold",
    color: "#d63384",
    marginBottom: "10px",
  },
  description: {
    fontSize: "18px",
    color: "#333",
    marginBottom: "20px",
    padding: "0 10px",
  },
  featuresContainer: {
    backgroundColor: "white",
    padding: "20px",
    borderRadius: "10px",
    boxShadow: "0px 2px 6px rgba(0, 0, 0, 0.1)",
    marginTop: "20px",
  },
  subheading: {
    fontSize: "22px",
    fontWeight: "bold",
    color: "#d63384",
    marginBottom: "10px",
  },
  featureList: {
    listStyle: "none",
    padding: "0",
    fontSize: "18px",
    color: "#444",
  },
};

export default About;
