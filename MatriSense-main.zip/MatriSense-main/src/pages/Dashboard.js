import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const data = [
  { date: "Day 1", heartRate: 75, bp: 120 },
  { date: "Day 2", heartRate: 78, bp: 122 },
  { date: "Day 3", heartRate: 80, bp: 130 },
  { date: "Day 4", heartRate: 85, bp: 140 },
];

function Dashboard() {
  return (
    <div className="container mt-5">
      <h2>Health Dashboard</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="heartRate" stroke="red" />
          <Line type="monotone" dataKey="bp" stroke="blue" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default Dashboard;
