import React, { useState } from "react";
import styled from "styled-components";

const TrackerContainer = styled.div`
  background: #f8f9fa;
  padding: 20px;
  margin: 20px;
  border-radius: 10px;
`;

function SymptomTracker() {
  const [symptoms, setSymptoms] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Symptoms recorded: ${symptoms}`);
  };

  return (
    <TrackerContainer>
      <h3>Track Your Symptoms</h3>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter symptoms..."
          value={symptoms}
          onChange={(e) => setSymptoms(e.target.value)}
        />
        <button type="submit">Submit</button>
      </form>
    </TrackerContainer>
  );
}

export default SymptomTracker;
