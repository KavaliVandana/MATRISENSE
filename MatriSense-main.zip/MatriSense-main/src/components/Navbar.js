import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";

const NavbarContainer = styled.nav`
  background: linear-gradient(90deg, #ff69b4, #ff1493);
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Logo = styled.h1`
  color: white;
  font-size: 24px;
  font-weight: bold;
  margin: 0;
`;

const NavLinks = styled.ul`
  list-style: none;
  display: flex;
  gap: 20px;
  padding: 0;
  margin: 0;
  align-items: center;

  li {
    display: inline;
  }

  a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    font-size: 18px;
    transition: 0.3s;
  }

  a:hover {
    color: #ffd700;
  }
`;

const NavWrapper = styled.div`
  display: flex;
  justify-content: flex-end;
  flex-grow: 1;
`;

function Navbar() {
  const [username, setUsername] = useState(null);

  // Check if the user is logged in (stored in localStorage)
  useEffect(() => {
    const storedUser = localStorage.getItem("username");
    if (storedUser) {
      setUsername(storedUser);
    }
  }, []);

  return (
    <NavbarContainer>
      <Logo>MatriSense</Logo>
      <NavWrapper>
        <NavLinks>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/food">Food</Link></li>
          <li><Link to="/exercise">Exercise</Link></li>
       
         
          
        </NavLinks>
      </NavWrapper>
    </NavbarContainer>
  );
}

export default Navbar;
