import React, { useState } from "react";

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { sender: "bot", text: "Hello! How can I assist you today?" },
  ]);

  const faq = {
    // Pregnancy Risk Questions
    "What factors determine pregnancy risk levels?":
      "Risk levels are based on age, blood pressure, blood sugar, body temperature, and heart rate.",
    "What should I do if my risk level is High?":
      "You should consult a doctor immediately, monitor vital signs, and follow a strict health plan.",
    "How often should I check my pregnancy risk level?":
      "It’s best to check at least once a month or if you experience unusual symptoms.",
    "Can high blood pressure affect pregnancy risk?":
      "Yes, high blood pressure increases the risk of complications such as preeclampsia.",
    "What are the symptoms of high pregnancy risk?":
      "Dizziness, excessive swelling, abnormal heart rate, high BP, and abnormal sugar levels.",

    // Food and Nutrition
    "What foods should I eat during pregnancy?":
      "You should eat fruits, vegetables, whole grains, lean protein, and dairy. Avoid processed foods and too much caffeine.",
    "Are there any foods to avoid while pregnant?":
      "Avoid raw seafood, unpasteurized dairy, processed meats, and excessive caffeine.",
    "Can I drink coffee during pregnancy?":
      "Yes, but limit caffeine intake to 200 mg per day (about one cup of coffee).",

    // Weather Conditions
    "Can extreme weather affect pregnancy?":
      "Yes, high heat can cause dehydration and dizziness, while cold weather increases the risk of infections. Stay hydrated and dress appropriately.",
    "Is it safe to travel in winter during pregnancy?":
      "Yes, but dress warmly, stay hydrated, and avoid icy surfaces to prevent falls.",

    // Pain and Discomfort
    "What causes back pain during pregnancy?":
      "Back pain is common due to weight gain and hormonal changes. Try prenatal yoga and maintain good posture.",
    "Is abdominal pain normal during pregnancy?":
      "Mild abdominal pain is normal due to stretching muscles, but severe pain should be checked by a doctor.",
    "Why do my legs cramp at night during pregnancy?":
      "Leg cramps are common due to increased weight and circulation changes. Stretching and hydration can help.",

    // Health Conditions
    "What is gestational diabetes?":
      "Gestational diabetes is high blood sugar during pregnancy. It can be managed with diet, exercise, and medication if needed.",
    "How can I prevent anemia during pregnancy?":
      "Eat iron-rich foods like spinach, red meat, and lentils. Your doctor may also recommend iron supplements.",
    "What should I do if I feel dizzy often?":
      "Dizziness can be caused by low blood sugar or dehydration. Eat small meals, drink plenty of water, and avoid standing up too fast.",

    // Sleep and Rest
    "Why is it hard to sleep during pregnancy?":
      "Hormonal changes, frequent urination, and body discomfort can disrupt sleep. Try sleeping on your left side and use pillows for support.",
    "What is the best sleeping position during pregnancy?":
      "Sleeping on your left side improves blood flow to the baby. Avoid sleeping on your back after the second trimester.",
    "How many hours should a pregnant woman sleep?":
      "Aim for 7-9 hours of sleep per night for good health.",

    // Baby and Mother Care
    "How do I take care of my baby after birth?":
      "Ensure proper feeding, hygiene, and sleep schedules. Visit the pediatrician regularly and create a safe environment at home.",
    "How can I recover faster after delivery?":
      "Rest, eat nutritious food, stay hydrated, and do gentle exercises when advised by your doctor.",
    "When can I start exercising after childbirth?":
      "Light exercise like walking can be done after a few weeks, but wait at least 6 weeks before intense workouts (consult your doctor).",
  };

  const handleUserInput = (question) => {
    const botResponse = faq[question] || "I'm sorry, I don't have an answer for that.";
    setMessages([...messages, { sender: "user", text: question }, { sender: "bot", text: botResponse }]);
  };

  return (
    <div>
      {/* Chatbot Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        style={{
          position: "fixed",
          bottom: "20px",
          right: "20px",
          backgroundColor: "#ff1493",
          color: "white",
          border: "none",
          padding: "10px 15px",
          borderRadius: "50%",
          fontSize: "16px",
          cursor: "pointer",
        }}
      >
        💬
      </button>

      {/* Chatbot Box */}
      {isOpen && (
        <div
          style={{
            position: "fixed",
            bottom: "80px",
            right: "20px",
            width: "300px",
            backgroundColor: "white",
            borderRadius: "10px",
            boxShadow: "2px 2px 10px rgba(0,0,0,0.3)",
            padding: "10px",
            fontSize: "14px",
          }}
        >
          <h3 style={{ color: "#ff1493", textAlign: "center" }}>Pregnancy Chatbot</h3>
          <div style={{ maxHeight: "200px", overflowY: "auto", padding: "5px", borderBottom: "1px solid #ddd" }}>
            {messages.map((msg, index) => (
              <div
                key={index}
                style={{
                  textAlign: msg.sender === "user" ? "right" : "left",
                  backgroundColor: msg.sender === "user" ? "#ffe4e1" : "#f8f8f8",
                  padding: "5px",
                  margin: "5px",
                  borderRadius: "5px",
                }}
              >
                {msg.text}
              </div>
            ))}
          </div>

          {/* Question Buttons */}
          <div style={{ marginTop: "10px" }}>
            {Object.keys(faq).map((question, index) => (
              <button
                key={index}
                onClick={() => handleUserInput(question)}
                style={{
                  display: "block",
                  width: "100%",
                  textAlign: "left",
                  backgroundColor: "#ff1493",
                  color: "white",
                  border: "none",
                  padding: "5px",
                  borderRadius: "5px",
                  marginTop: "5px",
                  cursor: "pointer",
                  fontSize: "12px",
                }}
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
