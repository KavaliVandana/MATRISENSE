import React from "react";

function DoctorRecommendation() {
    return (
        <div>
            <h2>Doctor Recommendations</h2>
            <p>Based on your symptoms, we recommend you consult a specialist.</p>
            <button>Find a Doctor</button>
        </div>
    );
}

export default DoctorRecommendation;
