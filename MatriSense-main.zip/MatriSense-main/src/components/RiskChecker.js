import React, { useState } from "react";

const RiskChecker = () => {
    const [features, setFeatures] = useState({
        Age: "",
        SystolicBP: "",
        DiastolicBP: "",
        BS: "",
        BodyTemp: "",
        HeartRate: ""
    });

    const [result, setResult] = useState(null);
    const [error, setError] = useState(null);

    // Handle input change
    const handleChange = (e) => {
        setFeatures({ ...features, [e.target.name]: e.target.value });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent page refresh
        setError(null);
        setResult(null);

        const requestData = {
            features: Object.values(features).map(Number) // Convert inputs to numbers
        };

        console.log("Sending request:", requestData); // Debugging log

        try {
            const response = await fetch("http://127.0.0.1:5000/predict", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(requestData),
            });

            const data = await response.json();
            console.log("API Response:", data); // Debugging log

            if (response.ok) {
                setResult(data);
            } else {
                setError(data.error || "Prediction failed");
            }
        } catch (err) {
            console.error("Fetch error:", err);
            setError("Server not responding");
        }
    };

    return (
        <div style={styles.container}>
            <h2>Maternal Health Risk Checker</h2>
            <form onSubmit={handleSubmit} style={styles.form}>
                {Object.keys(features).map((key) => (
                    <div key={key} style={styles.inputGroup}>
                        <label>{key}</label>
                        <input
                            type="number"
                            name={key}
                            value={features[key]}
                            onChange={handleChange}
                            required
                        />
                    </div>
                ))}
                <button type="submit" style={styles.button}>Check Risk Level</button>
            </form>

            {result && (
                <div style={styles.result}>
                    <h3>Predicted Risk: {result.risk}</h3>
                    <p>{result.suggestion}</p>
                </div>
            )}

            {error && <p style={styles.error}>{error}</p>}
        </div>
    );
};

// CSS-in-JS styles
const styles = {
    container: { textAlign: "center", padding: "20px" },
    form: { display: "flex", flexDirection: "column", alignItems: "center" },
    inputGroup: { margin: "10px" },
    button: { padding: "10px 20px", background: "#007bff", color: "white", border: "none", cursor: "pointer" },
    result: { marginTop: "20px", padding: "10px", background: "#d4edda", borderRadius: "5px" },
    error: { color: "red" }
};

export default RiskChecker;
