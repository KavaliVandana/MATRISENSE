// Footer.js
import React from "react";

function Footer() {
  return (
    <footer style={styles.footer}>
      <p>&copy; 2025 Maternal Health Monitor. All rights reserved.</p>
    </footer>
  );
}

const styles = {
  footer: {
    textAlign: "center",
    padding: "10px",
    backgroundColor: "#ff1493",
    color: "white",
    position: "relative", // Changed from fixed to relative to prevent overlap
    bottom: "0",
    width: "100%",
    marginTop: "auto", // Ensures the footer is at the bottom without covering content
  },
};

export default Footer;
