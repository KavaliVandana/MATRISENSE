import React from "react";
import styled from "styled-components";

const AlertBox = styled.div`
  background: red;
  color: white;
  padding: 15px;
  text-align: center;
  font-size: 18px;
`;

function EmergencyAlert() {
  return <AlertBox>🚨 Emergency Alert System Activated 🚨</AlertBox>;
}

export default EmergencyAlert;

